var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/data-hub/local-bodies/route.js")
R.c("server/chunks/[root-of-the-server]__1_r8za9._.js")
R.c("server/chunks/src_utils_supabase_admin_ts_0hwalns._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_next-internal_server_app_api_data-hub_local-bodies_route_actions_1tlfkxi.js")
R.m(86043)
module.exports=R.m(86043).exports
