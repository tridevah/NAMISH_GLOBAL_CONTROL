var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/data-hub/wards/route.js")
R.c("server/chunks/[root-of-the-server]__1bjfle9._.js")
R.c("server/chunks/src_utils_supabase_admin_ts_0hwalns._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_next-internal_server_app_api_data-hub_wards_route_actions_0pry08i.js")
R.m(98323)
module.exports=R.m(98323).exports
