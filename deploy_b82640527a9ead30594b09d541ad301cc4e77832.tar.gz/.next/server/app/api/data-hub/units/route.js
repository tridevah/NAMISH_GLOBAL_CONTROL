var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/data-hub/units/route.js")
R.c("server/chunks/[root-of-the-server]__1ktai1a._.js")
R.c("server/chunks/_0h0xkeq._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/src_utils_supabase_admin_ts_0hwalns._.js")
R.c("server/chunks/_0llx6m_._.js")
R.c("server/chunks/_next-internal_server_app_api_data-hub_units_route_actions_1f9624-.js")
R.m(39362)
module.exports=R.m(39362).exports
