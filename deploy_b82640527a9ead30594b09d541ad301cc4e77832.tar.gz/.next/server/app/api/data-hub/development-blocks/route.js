var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/data-hub/development-blocks/route.js")
R.c("server/chunks/[root-of-the-server]__0fgycyc._.js")
R.c("server/chunks/src_utils_supabase_admin_ts_0hwalns._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_next-internal_server_app_api_data-hub_development-blocks_route_actions_13a-1ch.js")
R.m(53710)
module.exports=R.m(53710).exports
