var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/data-hub/tax/authorities/route.js")
R.c("server/chunks/[root-of-the-server]__1vsmujl._.js")
R.c("server/chunks/_0llx6m_._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/src_utils_supabase_admin_ts_0hwalns._.js")
R.c("server/chunks/_next-internal_server_app_api_data-hub_tax_authorities_route_actions_0akxva9.js")
R.m(73253)
module.exports=R.m(73253).exports
