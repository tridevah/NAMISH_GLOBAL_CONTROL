var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/data-hub/tax/scope-geographies/route.js")
R.c("server/chunks/[root-of-the-server]__1p510sj._.js")
R.c("server/chunks/_0llx6m_._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/src_utils_supabase_admin_ts_0hwalns._.js")
R.c("server/chunks/1oeh_server_app_api_data-hub_tax_scope-geographies_route_actions_0o7-69a.js")
R.m(2616)
module.exports=R.m(2616).exports
