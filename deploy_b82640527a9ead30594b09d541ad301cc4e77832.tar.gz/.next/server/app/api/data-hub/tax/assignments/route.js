var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/data-hub/tax/assignments/route.js")
R.c("server/chunks/[root-of-the-server]__1ppx104._.js")
R.c("server/chunks/_0llx6m_._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/src_utils_supabase_admin_ts_0hwalns._.js")
R.c("server/chunks/_next-internal_server_app_api_data-hub_tax_assignments_route_actions_11u4puv.js")
R.m(24899)
module.exports=R.m(24899).exports
