var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/data-hub/tax/jurisdictions/route.js")
R.c("server/chunks/[root-of-the-server]__08y0qvp._.js")
R.c("server/chunks/_0llx6m_._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/src_utils_supabase_admin_ts_0hwalns._.js")
R.c("server/chunks/_next-internal_server_app_api_data-hub_tax_jurisdictions_route_actions_0_x4rdq.js")
R.m(80464)
module.exports=R.m(80464).exports
