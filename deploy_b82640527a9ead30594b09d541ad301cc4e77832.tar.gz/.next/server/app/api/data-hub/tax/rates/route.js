var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/data-hub/tax/rates/route.js")
R.c("server/chunks/[root-of-the-server]__1cvu8_o._.js")
R.c("server/chunks/_0llx6m_._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/src_utils_supabase_admin_ts_0hwalns._.js")
R.c("server/chunks/_next-internal_server_app_api_data-hub_tax_rates_route_actions_01flxsz.js")
R.m(58551)
module.exports=R.m(58551).exports
