var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/s2s/provision-enterprise/route.js")
R.c("server/chunks/[externals]__14kfdpf._.js")
R.c("server/chunks/_1uzki_9._.js")
R.c("server/chunks/node_modules_jose_dist_webapi_jwt_verify_1fkahuh.js")
R.c("server/chunks/src_utils_supabase_admin_ts_0hwalns._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_next-internal_server_app_api_s2s_provision-enterprise_route_actions_10ig6nu.js")
R.m(94006)
module.exports=R.m(94006).exports
