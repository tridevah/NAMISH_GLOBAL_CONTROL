var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/s2s/master-data/taxes/route.js")
R.c("server/chunks/[root-of-the-server]__1x80_yk._.js")
R.c("server/chunks/node_modules_jose_dist_webapi_jwt_verify_1fkahuh.js")
R.c("server/chunks/src_utils_supabase_admin_ts_0hwalns._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_next-internal_server_app_api_s2s_master-data_taxes_route_actions_1wv-5_z.js")
R.m(24870)
module.exports=R.m(24870).exports
