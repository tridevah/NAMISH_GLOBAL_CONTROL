var R=require("../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/s2s/master-data/geography/units/route.js")
R.c("server/chunks/[externals]__14kfdpf._.js")
R.c("server/chunks/_0gr8lwt._.js")
R.c("server/chunks/node_modules_jose_dist_webapi_jwt_verify_1fkahuh.js")
R.c("server/chunks/src_utils_supabase_admin_ts_0hwalns._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/1oeh_server_app_api_s2s_master-data_geography_units_route_actions_1cpm-g3.js")
R.m(46136)
module.exports=R.m(46136).exports
