var R=require("../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/s2s/master-data/geography/levels/route.js")
R.c("server/chunks/[root-of-the-server]__1gnbqvs._.js")
R.c("server/chunks/node_modules_jose_dist_webapi_jwt_verify_1fkahuh.js")
R.c("server/chunks/src_utils_supabase_admin_ts_0hwalns._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/1oeh_server_app_api_s2s_master-data_geography_levels_route_actions_0jb67gi.js")
R.m(99887)
module.exports=R.m(99887).exports
