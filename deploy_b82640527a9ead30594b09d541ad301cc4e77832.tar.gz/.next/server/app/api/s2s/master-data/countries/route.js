var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/s2s/master-data/countries/route.js")
R.c("server/chunks/[externals]__14kfdpf._.js")
R.c("server/chunks/_1ej6i1b._.js")
R.c("server/chunks/node_modules_jose_dist_webapi_jwt_verify_1fkahuh.js")
R.c("server/chunks/src_utils_supabase_admin_ts_0hwalns._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_next-internal_server_app_api_s2s_master-data_countries_route_actions_0eix0uc.js")
R.m(934)
module.exports=R.m(934).exports
