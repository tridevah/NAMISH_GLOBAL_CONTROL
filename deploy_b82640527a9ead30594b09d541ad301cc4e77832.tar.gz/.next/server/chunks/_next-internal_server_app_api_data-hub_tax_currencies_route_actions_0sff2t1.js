module.exports=[91840,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_data-hub_tax_currencies_route_actions_0sff2t1.js.map