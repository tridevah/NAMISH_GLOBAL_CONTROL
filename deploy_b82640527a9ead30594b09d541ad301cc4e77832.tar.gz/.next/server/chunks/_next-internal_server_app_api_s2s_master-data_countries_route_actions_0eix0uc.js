module.exports=[1504,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_s2s_master-data_countries_route_actions_0eix0uc.js.map