module.exports=[19542,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_data-hub_countries_route_actions_1lw07dj.js.map