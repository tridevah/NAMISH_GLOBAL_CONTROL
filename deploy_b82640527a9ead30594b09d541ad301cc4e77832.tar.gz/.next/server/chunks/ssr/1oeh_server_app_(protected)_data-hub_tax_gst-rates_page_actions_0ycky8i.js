module.exports=[31067,(a,b,c)=>{}];

//# sourceMappingURL=1oeh_server_app_%28protected%29_data-hub_tax_gst-rates_page_actions_0ycky8i.js.map