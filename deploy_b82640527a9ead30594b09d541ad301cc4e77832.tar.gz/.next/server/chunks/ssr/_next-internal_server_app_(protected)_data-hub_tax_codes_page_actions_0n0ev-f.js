module.exports=[16127,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28protected%29_data-hub_tax_codes_page_actions_0n0ev-f.js.map