module.exports=[74384,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28protected%29_data-hub_tax_coverage_page_actions_1hsjra4.js.map