module.exports=[62746,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28protected%29_data-hub_tax_regimes_page_actions_199a2_y.js.map