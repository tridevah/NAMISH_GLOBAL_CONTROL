module.exports=[65692,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28protected%29_data-hub_units_page_actions_0p2iakb.js.map