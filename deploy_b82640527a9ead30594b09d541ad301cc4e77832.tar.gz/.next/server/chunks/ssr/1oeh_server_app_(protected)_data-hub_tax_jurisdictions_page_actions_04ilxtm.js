module.exports=[27972,(a,b,c)=>{}];

//# sourceMappingURL=1oeh_server_app_%28protected%29_data-hub_tax_jurisdictions_page_actions_04ilxtm.js.map