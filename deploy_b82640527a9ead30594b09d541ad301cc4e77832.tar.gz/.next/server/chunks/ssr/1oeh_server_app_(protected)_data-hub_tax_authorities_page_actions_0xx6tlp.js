module.exports=[56505,(a,b,c)=>{}];

//# sourceMappingURL=1oeh_server_app_%28protected%29_data-hub_tax_authorities_page_actions_0xx6tlp.js.map