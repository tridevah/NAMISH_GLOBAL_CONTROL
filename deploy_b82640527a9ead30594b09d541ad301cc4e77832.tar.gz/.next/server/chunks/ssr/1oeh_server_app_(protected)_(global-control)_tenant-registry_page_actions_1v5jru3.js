module.exports=[24635,(a,b,c)=>{}];

//# sourceMappingURL=1oeh_server_app_%28protected%29_%28global-control%29_tenant-registry_page_actions_1v5jru3.js.map