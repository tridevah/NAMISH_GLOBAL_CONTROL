module.exports=[84728,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28protected%29_data-hub_page_actions_0omwp4r.js.map