module.exports=[49629,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28protected%29_data-hub_tax_scopes_page_actions_1rzz0oc.js.map