module.exports=[22945,(a,b,c)=>{}];

//# sourceMappingURL=1oeh_server_app_%28protected%29_data-hub_tax_component-sets_page_actions_0in7irh.js.map