module.exports=[32266,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28protected%29_%28global-control%29_page_actions_15u8atp.js.map