module.exports=[86076,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28protected%29_data-hub_tax_hsn-sac_page_actions_07_qisn.js.map