module.exports=[36688,(a,b,c)=>{}];

//# sourceMappingURL=1oeh_server_app_%28protected%29_data-hub_tax_currency-assignments_page_actions_11ksb2o.js.map