module.exports=[77230,(a,b,c)=>{}];

//# sourceMappingURL=1oeh_server_app_%28protected%29_data-hub_tax_components_page_actions_0c0tcb-.js.map