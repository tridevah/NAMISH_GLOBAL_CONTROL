module.exports=[34831,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_data-hub_tax_authorities_route_actions_0akxva9.js.map