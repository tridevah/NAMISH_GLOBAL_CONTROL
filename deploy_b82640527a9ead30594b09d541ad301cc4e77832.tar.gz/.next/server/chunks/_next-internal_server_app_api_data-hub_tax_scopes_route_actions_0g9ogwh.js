module.exports=[99294,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_data-hub_tax_scopes_route_actions_0g9ogwh.js.map