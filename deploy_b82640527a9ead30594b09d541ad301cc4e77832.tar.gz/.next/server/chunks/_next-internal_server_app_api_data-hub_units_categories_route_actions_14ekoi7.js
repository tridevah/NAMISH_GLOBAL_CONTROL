module.exports=[39095,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_data-hub_units_categories_route_actions_14ekoi7.js.map