module.exports=[83879,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_data-hub_local-bodies_route_actions_1tlfkxi.js.map