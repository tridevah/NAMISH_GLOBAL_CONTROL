module.exports=[31540,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_data-hub_units_route_actions_1f9624-.js.map