module.exports=[96035,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_data-hub_development-blocks_route_actions_13a-1ch.js.map