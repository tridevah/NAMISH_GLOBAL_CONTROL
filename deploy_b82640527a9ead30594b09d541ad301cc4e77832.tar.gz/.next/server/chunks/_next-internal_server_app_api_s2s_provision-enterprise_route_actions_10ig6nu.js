module.exports=[10979,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_s2s_provision-enterprise_route_actions_10ig6nu.js.map