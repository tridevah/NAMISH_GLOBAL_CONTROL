module.exports=[23795,(e,o,d)=>{}];

//# sourceMappingURL=1oeh_server_app_api_data-hub_tax_scope-geographies_route_actions_0o7-69a.js.map