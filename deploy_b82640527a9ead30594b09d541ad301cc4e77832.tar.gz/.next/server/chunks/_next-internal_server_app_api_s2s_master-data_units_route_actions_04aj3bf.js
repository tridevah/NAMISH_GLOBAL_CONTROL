module.exports=[79089,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_s2s_master-data_units_route_actions_04aj3bf.js.map