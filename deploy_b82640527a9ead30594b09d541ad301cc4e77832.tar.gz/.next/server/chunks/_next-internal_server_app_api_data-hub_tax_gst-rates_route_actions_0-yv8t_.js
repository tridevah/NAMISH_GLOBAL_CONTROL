module.exports=[12017,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_data-hub_tax_gst-rates_route_actions_0-yv8t_.js.map