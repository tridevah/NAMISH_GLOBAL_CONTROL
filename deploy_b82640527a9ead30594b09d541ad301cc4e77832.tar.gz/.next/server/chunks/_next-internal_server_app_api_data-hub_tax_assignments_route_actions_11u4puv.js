module.exports=[46358,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_data-hub_tax_assignments_route_actions_11u4puv.js.map