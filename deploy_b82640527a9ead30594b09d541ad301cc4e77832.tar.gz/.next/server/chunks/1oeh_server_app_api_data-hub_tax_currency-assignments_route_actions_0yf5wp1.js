module.exports=[82362,(e,o,d)=>{}];

//# sourceMappingURL=1oeh_server_app_api_data-hub_tax_currency-assignments_route_actions_0yf5wp1.js.map