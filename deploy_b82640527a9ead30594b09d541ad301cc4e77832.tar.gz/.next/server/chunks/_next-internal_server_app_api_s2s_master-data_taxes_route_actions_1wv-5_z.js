module.exports=[49641,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_s2s_master-data_taxes_route_actions_1wv-5_z.js.map