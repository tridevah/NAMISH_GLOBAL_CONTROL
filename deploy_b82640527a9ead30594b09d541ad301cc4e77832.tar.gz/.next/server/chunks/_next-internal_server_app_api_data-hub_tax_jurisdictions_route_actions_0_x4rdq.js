module.exports=[94715,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_data-hub_tax_jurisdictions_route_actions_0_x4rdq.js.map