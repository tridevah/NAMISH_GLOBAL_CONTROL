module.exports=[27025,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_data-hub_tax_components_route_actions_1on6ku2.js.map