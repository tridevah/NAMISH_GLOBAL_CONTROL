module.exports=[12703,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_data-hub_tax_regimes_route_actions_1vs31je.js.map