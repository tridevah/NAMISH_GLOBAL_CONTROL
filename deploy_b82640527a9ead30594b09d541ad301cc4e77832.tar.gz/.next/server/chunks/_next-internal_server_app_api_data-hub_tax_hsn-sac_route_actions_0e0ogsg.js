module.exports=[65884,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_data-hub_tax_hsn-sac_route_actions_0e0ogsg.js.map