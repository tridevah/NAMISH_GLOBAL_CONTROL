module.exports=[82007,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_data-hub_wards_route_actions_0pry08i.js.map