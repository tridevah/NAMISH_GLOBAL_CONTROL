globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/Y9U3fOQEkM9ZSII8q5kot/_buildManifest.js",
    "static/Y9U3fOQEkM9ZSII8q5kot/_ssgManifest.js",
    "static/Y9U3fOQEkM9ZSII8q5kot/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/310vm2bl3xxpt.js",
    "static/chunks/2mmpezlrfmbu5.js",
    "static/chunks/3byuobrkyz9bj.js",
    "static/chunks/3-xpmlk5hluyb.js",
    "static/chunks/11be91k_gj8bl.js",
    "static/chunks/turbopack-3f9dlf6wkixxm.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {},
  "chunkLoadingGlobal": "TURBOPACK"
};
