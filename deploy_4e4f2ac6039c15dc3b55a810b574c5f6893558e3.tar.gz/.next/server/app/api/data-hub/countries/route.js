var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/data-hub/countries/route.js")
R.c("server/chunks/[root-of-the-server]__1ts2ucm._.js")
R.c("server/chunks/src_utils_supabase_admin_ts_0hwalns._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_next-internal_server_app_api_data-hub_countries_route_actions_1lw07dj.js")
R.m(8471)
module.exports=R.m(8471).exports
