var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/data-hub/units/categories/route.js")
R.c("server/chunks/[root-of-the-server]__1b8kp_u._.js")
R.c("server/chunks/src_utils_supabase_admin_ts_0hwalns._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_next-internal_server_app_api_data-hub_units_categories_route_actions_14ekoi7.js")
R.m(58072)
module.exports=R.m(58072).exports
