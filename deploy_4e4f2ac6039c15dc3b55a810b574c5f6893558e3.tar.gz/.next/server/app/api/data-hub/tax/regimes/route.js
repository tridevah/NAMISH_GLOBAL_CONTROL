var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/data-hub/tax/regimes/route.js")
R.c("server/chunks/[root-of-the-server]__14eh27n._.js")
R.c("server/chunks/src_utils_supabase_admin_ts_0hwalns._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_next-internal_server_app_api_data-hub_tax_regimes_route_actions_1vs31je.js")
R.m(64599)
module.exports=R.m(64599).exports
