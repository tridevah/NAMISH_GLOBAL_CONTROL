var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/data-hub/tax/hsn-sac/route.js")
R.c("server/chunks/[root-of-the-server]__01r9s0p._.js")
R.c("server/chunks/src_utils_supabase_admin_ts_0hwalns._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_next-internal_server_app_api_data-hub_tax_hsn-sac_route_actions_0e0ogsg.js")
R.m(23213)
module.exports=R.m(23213).exports
