var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/data-hub/tax/scopes/route.js")
R.c("server/chunks/[root-of-the-server]__1dofxil._.js")
R.c("server/chunks/src_utils_supabase_admin_ts_0hwalns._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_next-internal_server_app_api_data-hub_tax_scopes_route_actions_0g9ogwh.js")
R.m(20192)
module.exports=R.m(20192).exports
