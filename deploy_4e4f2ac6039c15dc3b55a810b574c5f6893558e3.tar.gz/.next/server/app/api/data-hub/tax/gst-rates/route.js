var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/data-hub/tax/gst-rates/route.js")
R.c("server/chunks/[root-of-the-server]__0ok54ok._.js")
R.c("server/chunks/src_utils_supabase_admin_ts_0hwalns._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_next-internal_server_app_api_data-hub_tax_gst-rates_route_actions_0-yv8t_.js")
R.m(40645)
module.exports=R.m(40645).exports
