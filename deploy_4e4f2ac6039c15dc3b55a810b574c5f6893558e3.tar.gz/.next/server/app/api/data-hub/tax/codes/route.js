var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/data-hub/tax/codes/route.js")
R.c("server/chunks/[root-of-the-server]__0nbqw3m._.js")
R.c("server/chunks/src_utils_supabase_admin_ts_0hwalns._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_next-internal_server_app_api_data-hub_tax_codes_route_actions_1ztjfwa.js")
R.m(62083)
module.exports=R.m(62083).exports
