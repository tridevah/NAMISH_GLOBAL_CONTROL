var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/data-hub/tax/currency-assignments/route.js")
R.c("server/chunks/[root-of-the-server]__01u3klz._.js")
R.c("server/chunks/src_utils_supabase_admin_ts_0hwalns._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/1oeh_server_app_api_data-hub_tax_currency-assignments_route_actions_0yf5wp1.js")
R.m(59083)
module.exports=R.m(59083).exports
