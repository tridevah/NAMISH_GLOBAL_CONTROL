var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/data-hub/tax/components/route.js")
R.c("server/chunks/[root-of-the-server]__20x0k82._.js")
R.c("server/chunks/src_utils_supabase_admin_ts_0hwalns._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_next-internal_server_app_api_data-hub_tax_components_route_actions_1on6ku2.js")
R.m(18330)
module.exports=R.m(18330).exports
