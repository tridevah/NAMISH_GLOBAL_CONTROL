globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/1Eofi1rNwCTQoViWUm658/_buildManifest.js",
    "static/1Eofi1rNwCTQoViWUm658/_ssgManifest.js",
    "static/1Eofi1rNwCTQoViWUm658/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/310vm2bl3xxpt.js",
    "static/chunks/2mmpezlrfmbu5.js",
    "static/chunks/3byuobrkyz9bj.js",
    "static/chunks/3-xpmlk5hluyb.js",
    "static/chunks/11be91k_gj8bl.js",
    "static/chunks/turbopack-3f9dlf6wkixxm.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {},
  "chunkLoadingGlobal": "TURBOPACK"
};
